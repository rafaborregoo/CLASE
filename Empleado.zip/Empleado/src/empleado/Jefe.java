/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package empleado;

/**
 *
 * @author AlumnoDam18
 */
public class Jefe extends Empleado{
    int tel_movil;
    int n_empleado;
    double comision;
    String departamento;
    
    public int getTel_movil(){
        return tel_movil;
    }
    public void setTel_movil(){
        this.tel_movil = tel_movil;
    }
    public int getN_empleado(){
        return n_empleado;
    }
    public void setN_empleado(){
        this.n_empleado = n_empleado
    }
}
