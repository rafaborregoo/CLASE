/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package empleado;

import java.util.Scanner;


public class Administrativo extends Empleado{
    String puesto;
    int num_puesto;
    String dir_oficina;
    String nom_oficina;
    double sueldo;
    
    public String getPuesto(){
        return puesto;
    }
    public void setPuesto(){
        this.puesto = puesto;
    }
    public int getNum_puesto(){
        return num_puesto;
    }
    public void setNum_puesto(){
        this.num_puesto = num_puesto;
    }
    public String getDir_oficina(){
        return dir_oficina;
    }
    public void setDir_oficina(){
        this.dir_oficina = dir_oficina;
    }
    public String getNom_oficina(){
        return nom_oficina;
    }
    public void setNom_oficina(){
        this.nom_oficina = nom_oficina;
    }
    public double getSueldo(){
        return sueldo;
    }
    public void setSueldo(){
        this.sueldo = sueldo;
    }
    public void aumentarSueldo(double sueldo){
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce el sueldo: ");
        this.sueldo = this.sueldo + sc.nextInt();
    }

    public Administrativo(String nombre, String apellido, String direccion, String localidad, String puesto, String dir_oficina, String nom_oficina, double sueldo) {
        this.puesto = puesto;
        this.dir_oficina = dir_oficina;
        this.nom_oficina = nom_oficina;
        this.sueldo = sueldo;
        this.nombre = nombre;
        this.apellido = apellido;
        this.direccion = direccion;
        this.localidad = localidad;
    }

    
    
}
