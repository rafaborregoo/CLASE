/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package empleado;

/**
 *
 * @author AlumnoDam18
 */
public class Vendedor extends Empleado{
    String zona;
    int n_clientes;
    String tipo_producto;
    
    public String getZona(){
        return zona;
    }
    public void setZona(){
        this.zona = zona;
    }
    public int getN_clientes(){
        return n_clientes;
    }
    public void setN_clientes(){
        this.n_clientes = n_clientes;
    }
    public String getTipo_producto(){
        return tipo_producto;
    }
    public void setTipo_producto(){
        this.tipo_producto = tipo_producto;
    }

    public Vendedor(String nombre, String apellido, String direccion, String localidad, int dni, String zona, int n_clientes, String tipo_producto) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.direccion = direccion;
        this.localidad = localidad;
        this.dni = dni;
        this.zona = zona;
        this.n_clientes = n_clientes;
        this.tipo_producto = tipo_producto;
        
    }
    
}
