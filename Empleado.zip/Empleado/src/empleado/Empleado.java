/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package empleado;

/**
 *
 * @author AlumnoDam18
 */
public class Empleado {
    String nombre;
    String apellido;
    String direccion;
    String localidad;
    int dni;
    
    public String getnombre(){
    return nombre;
}
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    public String getApellido(){
        return apellido;
    }
    public void setApellido(String apellido){
        this.apellido = apellido;
    }
    public String getDireccion(){
        return direccion;
    }
    public void setDireccion(){
        this.direccion = direccion;
    }
    public String getLocalidad(){
        return localidad;
    }
    public void setLocalidad(){
        this.localidad = localidad;
    }
    public int getDni(){
        return dni;
    }
    public void setDni(){
        this.dni = dni;
    }

    public Empleado(String nombre, String apellido, String direccion, String localidad) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.direccion = direccion;
        this.localidad = localidad;
    }
    
    public Empleado(){
        
    }
    
}
